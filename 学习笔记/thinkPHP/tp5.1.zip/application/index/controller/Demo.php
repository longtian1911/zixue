<?php

namespace app\index\controller;


use think\Controller;

class Demo extends Controller {

    // 前置操作方法列表  了解  检测
    /*protected $beforeActionList = [

        // 要触发方法   请求的方法，请求此方法，触发前面定义的方法
        'checkuser' => ['index','welcome']
    ];*/


    public function index() {

        //return $this->success('登录成功!','/index/demo/su');

        // 生成url地址函数
        // 同控制器下面可以直接写方法名
        //return $this->success('登录成功!',url('su'));
        // 不同的控制器下面可以写控制器名/方法名
        #return $this->success('登录成功!',url('index/index'));

        // 自定义路由
        #return $this->success('登录成功!',url('indexr'));

        return $this->success('登录成功!', url('indexr'), ['status' => 1]);

        //$this->error('我错了');

    }

    // 成功页面
    public function su() {
        return '我是成功页面';
    }

    /*protected function checkuser() {
        echo  '<hr>aaaa';
    }

    public function welcome() {
        return '<hr>bbbb';
    }*/


}